import React, { useState } from 'react';
import { Laptop, Download, CheckCircle2 } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { LaptopInstallModal } from './LaptopInstallModal';

interface LaptopInstallButtonProps {
  className?: string;
  compact?: boolean;
}

export const LaptopInstallButton: React.FC<LaptopInstallButtonProps> = ({
  className = '',
  compact = false,
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [modalOpen, setModalOpen] = useState(false);

  const handleClick = async () => {
    // If browser install prompt is directly primed and ready, trigger it
    if (isInstallable) {
      const installed = await install();
      if (!installed) {
        setModalOpen(true);
      }
    } else {
      // Otherwise open the guided laptop installation modal
      setModalOpen(true);
    }
  };

  return (
    <>
      <button
        onClick={handleClick}
        className={`group relative flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-mono transition-all cursor-pointer shadow-sm ${
          isInstalled
            ? 'bg-slate-900/80 border-slate-700/60 text-slate-400 hover:text-slate-200 hover:border-slate-600'
            : isInstallable
            ? 'bg-gradient-to-r from-purple-900/60 to-indigo-900/60 border-purple-500/50 text-purple-200 hover:border-purple-400 hover:from-purple-800/70 hover:to-indigo-800/70'
            : 'bg-slate-900/80 border-slate-700/60 text-slate-300 hover:border-purple-500/50 hover:text-white'
        } ${className}`}
        title={isInstalled ? 'Installed as Desktop App' : 'Install Remix Evo on your laptop'}
      >
        {isInstalled ? (
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
        ) : (
          <Laptop className="w-3.5 h-3.5 text-purple-400 group-hover:scale-110 transition-transform" />
        )}

        <span className="font-medium">
          {compact
            ? isInstalled
              ? 'Desktop'
              : 'Install'
            : isInstalled
            ? 'Laptop App'
            : 'Install on Laptop'}
        </span>

        {!isInstalled && isInstallable && (
          <span className="flex h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
        )}
      </button>

      <LaptopInstallModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
};
