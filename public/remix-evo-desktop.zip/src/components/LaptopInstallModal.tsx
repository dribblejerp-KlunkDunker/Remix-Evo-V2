import React, { useState } from 'react';
import {
  Laptop,
  Download,
  CheckCircle2,
  X,
  ExternalLink,
  Terminal,
  ShieldCheck,
  Sparkles,
  Apple,
  Monitor,
  Copy,
  Check,
  Zap,
  Layers,
  HelpCircle,
  HardDrive
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface LaptopInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LaptopInstallModal: React.FC<LaptopInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, os, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'pwa' | 'local' | 'chromebook'>('pwa');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const localInstallCommandMacLinux = `# 1. Clone repository to your laptop
git clone https://github.com/google-gemini/remix-agent-matrix.git
cd remix-agent-matrix

# 2. Install dependencies (Node 20+)
npm install

# 3. Copy environment secrets
cp .env.example .env

# 4. Launch full-stack autonomous matrix locally
npm run dev`;

  const localInstallCommandWindows = `# In PowerShell on your Windows laptop:
git clone https://github.com/google-gemini/remix-agent-matrix.git
cd remix-agent-matrix
npm install
Copy-Item .env.example .env
npm run dev`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-3xl max-h-[90vh] flex flex-col bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-100"
        role="dialog"
        aria-modal="true"
        aria-labelledby="laptop-install-title"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-950/80 border border-purple-500/40 text-purple-400">
              <Laptop className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="laptop-install-title" className="text-lg font-bold text-white tracking-wide">
                  Install on Your Laptop
                </h2>
                <span className="px-2 py-0.5 text-[10px] font-mono uppercase font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-500/40 rounded-full">
                  Standalone Desktop App
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Run Remix Evo natively on macOS, Windows, Linux, or Chromebook laptops
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-slate-800 bg-slate-900/60 px-6 pt-2">
          <button
            onClick={() => setActiveTab('pwa')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-medium border-b-2 transition ${
              activeTab === 'pwa'
                ? 'border-purple-500 text-purple-300 font-semibold bg-purple-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className="w-4 h-4 text-purple-400" />
            1-Click Desktop App (PWA)
          </button>
          <button
            onClick={() => setActiveTab('local')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-medium border-b-2 transition ${
              activeTab === 'local'
                ? 'border-purple-500 text-purple-300 font-semibold bg-purple-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-4 h-4 text-cyan-400" />
            Local Node.js Runner (Terminal)
          </button>
          <button
            onClick={() => setActiveTab('chromebook')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-medium border-b-2 transition ${
              activeTab === 'chromebook'
                ? 'border-purple-500 text-purple-300 font-semibold bg-purple-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <HardDrive className="w-4 h-4 text-emerald-400" />
            Chromebook Linux (.deb)
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeTab === 'pwa' && (
            <div className="space-y-6">
              {/* Primary Action Card */}
              <div className="p-5 rounded-xl bg-gradient-to-br from-purple-950/40 via-slate-900 to-indigo-950/30 border border-purple-500/30">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span className="text-xs font-mono font-semibold text-emerald-400">
                        {isInstalled ? 'Already Installed on this Device' : 'Ready to Install'}
                      </span>
                    </div>
                    <h3 className="text-base font-semibold text-white mt-1">
                      Install Remix Evo Desktop Window
                    </h3>
                    <p className="text-xs text-slate-300 mt-1 max-w-lg leading-relaxed">
                      Installs a dedicated desktop application icon on your laptop. Launches in an isolated window without browser tabs or URL bars, with offline caching and background synchronization.
                    </p>
                  </div>

                  {isInstalled ? (
                    <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-950/70 border border-emerald-500/50 text-emerald-300 text-xs font-medium">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      App Installed
                    </div>
                  ) : isInstallable ? (
                    <button
                      onClick={async () => {
                        const success = await install();
                        if (success) {
                          onClose();
                        }
                      }}
                      className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-medium text-xs shadow-lg shadow-purple-600/30 flex items-center gap-2 cursor-pointer transition transform active:scale-95"
                    >
                      <Download className="w-4 h-4" />
                      Install Now
                    </button>
                  ) : (
                    <div className="px-4 py-2 rounded-lg bg-slate-800/90 border border-slate-700 text-slate-300 text-xs">
                      See browser guide below
                    </div>
                  )}
                </div>
              </div>

              {/* Step-by-Step Instructions based on Browser/OS */}
              <div className="space-y-4">
                <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  How to install from your browser
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Chrome / Edge on Mac & Windows */}
                  <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
                    <div className="flex items-center gap-2 text-sky-400 text-sm font-semibold">
                      <Monitor className="w-4 h-4" />
                      Google Chrome & Microsoft Edge
                    </div>
                    <ol className="text-xs text-slate-300 space-y-2 list-decimal list-inside leading-relaxed">
                      <li>
                        Look at the right side of the URL address bar at the top of your screen.
                      </li>
                      <li>
                        Click the <span className="font-semibold text-white px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700">Install App</span> icon (or monitor with down arrow).
                      </li>
                      <li>
                        Click <strong className="text-white">Install</strong> when prompted.
                      </li>
                      <li>
                        Remix Evo opens immediately as an isolated laptop desktop program and adds an icon to your Applications and Desktop!
                      </li>
                    </ol>
                  </div>

                  {/* macOS Safari */}
                  <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
                    <div className="flex items-center gap-2 text-purple-400 text-sm font-semibold">
                      <Apple className="w-4 h-4" />
                      Apple Safari (macOS Sonoma+)
                    </div>
                    <ol className="text-xs text-slate-300 space-y-2 list-decimal list-inside leading-relaxed">
                      <li>
                        In the Safari top menu bar, click <strong className="text-white">File</strong>.
                      </li>
                      <li>
                        Select <span className="font-semibold text-white px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700">Add to Dock...</span>
                      </li>
                      <li>
                        Confirm the name as <em>Remix Evo</em> and click <strong className="text-white">Add</strong>.
                      </li>
                      <li>
                        The native macOS app is now in your Mac Dock and Launchpad!
                      </li>
                    </ol>
                  </div>
                </div>
              </div>

              {/* Status & Capabilities */}
              <div className="p-4 rounded-xl bg-slate-950/40 border border-slate-800/80">
                <h5 className="text-xs font-semibold text-slate-300 mb-2 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  What you get with the Laptop Desktop App:
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                    Isolated native window
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                    Offline asset caching
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                    Desktop & taskbar shortcuts
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'local' && (
            <div className="space-y-5">
              <div>
                <h3 className="text-sm font-semibold text-white">
                  Run Remix Evo Locally on Your Laptop (Node.js)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  If you want to run the full server and client directly on your laptop's local CPU using your own local environment:
                </p>
              </div>

              {/* Prerequisites */}
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-white">Prerequisites:</span> Node.js 20 or 22+ and Git installed on your laptop.
                </div>
                <a 
                  href="https://nodejs.org" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="text-purple-400 hover:text-purple-300 flex items-center gap-1 font-mono text-[11px]"
                >
                  Download Node.js <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Terminal Code Snippet (Mac / Linux) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-medium text-slate-300 flex items-center gap-1.5">
                    <Apple className="w-3.5 h-3.5 text-slate-400" /> macOS & Linux Terminal
                  </span>
                  <button
                    onClick={() => copyToClipboard(localInstallCommandMacLinux, 'mac')}
                    className="flex items-center gap-1 text-[11px] text-purple-400 hover:text-purple-300"
                  >
                    {copiedKey === 'mac' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    {copiedKey === 'mac' ? 'Copied!' : 'Copy Script'}
                  </button>
                </div>
                <pre className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-emerald-300 overflow-x-auto">
                  {localInstallCommandMacLinux}
                </pre>
              </div>

              {/* Terminal Code Snippet (Windows) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-medium text-slate-300 flex items-center gap-1.5">
                    <Monitor className="w-3.5 h-3.5 text-slate-400" /> Windows (PowerShell)
                  </span>
                  <button
                    onClick={() => copyToClipboard(localInstallCommandWindows, 'win')}
                    className="flex items-center gap-1 text-[11px] text-purple-400 hover:text-purple-300"
                  >
                    {copiedKey === 'win' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    {copiedKey === 'win' ? 'Copied!' : 'Copy Script'}
                  </button>
                </div>
                <pre className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-cyan-300 overflow-x-auto">
                  {localInstallCommandWindows}
                </pre>
              </div>
            </div>
          )}

          {activeTab === 'chromebook' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-white">
                  Chromebook Linux Package (amd64 / Crostini)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Built-in standalone package with desktop entries, system service, and secure credential vault for ChromeOS.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
                <div className="text-xs font-mono text-slate-300">
                  <span className="text-emerald-400 font-bold">1. Build or download .deb package:</span>
                </div>
                <pre className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-emerald-300">
npm run build:chromebook
                </pre>

                <div className="text-xs font-mono text-slate-300">
                  <span className="text-emerald-400 font-bold">2. Install into Linux subsystem:</span>
                </div>
                <pre className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-emerald-300">
sudo dpkg -i packaging/chromebook/remix-evo_0.2.0_amd64.deb
                </pre>

                <div className="text-xs font-mono text-slate-300">
                  <span className="text-emerald-400 font-bold">3. Launch from ChromeOS App Drawer or Terminal:</span>
                </div>
                <pre className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-emerald-300">
remix-evo
                </pre>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>Remix Evo Matrix v0.2.0</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
