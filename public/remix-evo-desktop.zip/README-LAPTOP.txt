===================================================================
Remix Evo - Autonomous Evolution Research Agent Matrix
Desktop Laptop Edition
===================================================================

HOW TO RUN ON YOUR LAPTOP:

WINDOWS LAPTOP:
1. Double-click "remix-evo-win.bat"
2. The batch script will check for Node.js, install dependencies if needed,
   start the server, and open http://localhost:3000 in your browser!

MACBOOK / MACOS:
1. Open Terminal and cd into this folder
2. Run:
   chmod +x remix-evo-mac-linux.sh
   ./remix-evo-mac-linux.sh
3. The app will launch and open http://localhost:3000!

LINUX LAPTOP:
1. Open terminal and run: ./remix-evo-mac-linux.sh
   (Or if on Ubuntu/Debian/Chromebook, install the .deb package directly)

CONFIGURING SECRETS:
- Open .env in any text editor.
- GEMINI_API_KEY is pre-configured.
- Add ANTHROPIC_API_KEY, OPENAI_API_KEY, DEEPSEEK_API_KEY, or GROQ_API_KEY as desired.
===================================================================
